# api-reprograma

[slides API](https://docs.google.com/presentation/d/1dtiJKya7TJaIsGu26OAUxAjkD6PLl8-3-Gzx0yT7Tw0/edit?usp=sharing)

[slides http](https://docs.google.com/presentation/d/1PmEigFefcOp0L-MW50nZr0hWhoJmb6RJcqS_NERhhAg/edit?usp=sharing)

[slides XMLHttpRequest](https://docs.google.com/presentation/d/136ZazuIONlyqEqflyBD1CI0njoctMa-98bMy9iztfCw/edit?usp=sharing)

[slides fetchAPI](https://docs.google.com/presentation/d/1_eaIDf3Iqop-RSuTeE8sLmooiIhKNV4L8ThHDYDCuG0/edit?usp=sharing)

## Desafio

Fazer uma chamada na api do viacep passando o valor de um cep (viacep.com.br/ws/${cep}/json/)
Pegar seu retorno e preencher os outros campos com a resposta da requisição